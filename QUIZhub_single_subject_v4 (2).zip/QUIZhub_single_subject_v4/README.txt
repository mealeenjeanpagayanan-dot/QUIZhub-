QUIZhub Version 4.0 — Teacher-generated class code

1. Extract this ZIP file.
2. Open the QUIZhub_single_subject_v4 folder.
3. Double-click index.html.
4. Sign in as Teacher (Admin).
5. Open My Classes and click Generate class code.
6. Share the generated code with your test student.
7. Sign out, sign in as Student, and submit the code to request class membership.
8. Sign in as Teacher again and approve the pending student request.

This is a local browser prototype. Data is stored in localStorage in the same browser profile. It is not a shared online database or secure authentication system.
